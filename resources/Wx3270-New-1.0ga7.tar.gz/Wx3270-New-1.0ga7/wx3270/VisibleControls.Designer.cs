﻿namespace Wx3270
{
    partial class VisibleControls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VisibleControls));
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.sfLabelV = new System.Windows.Forms.Label();
            this.sfLabelU = new System.Windows.Forms.Label();
            this.sfLabelT = new System.Windows.Forms.Label();
            this.sfLabelS = new System.Windows.Forms.Label();
            this.sfLabelR = new System.Windows.Forms.Label();
            this.sfLabelQ = new System.Windows.Forms.Label();
            this.sfLabelP = new System.Windows.Forms.Label();
            this.sfLabelO = new System.Windows.Forms.Label();
            this.sfLabelN = new System.Windows.Forms.Label();
            this.sfLabelM = new System.Windows.Forms.Label();
            this.sfLabelL = new System.Windows.Forms.Label();
            this.sfLabelK = new System.Windows.Forms.Label();
            this.sfLabelJ = new System.Windows.Forms.Label();
            this.sfLabelI = new System.Windows.Forms.Label();
            this.sfLabelH = new System.Windows.Forms.Label();
            this.sfLabelG = new System.Windows.Forms.Label();
            this.sfLabelF = new System.Windows.Forms.Label();
            this.sfLlabelE = new System.Windows.Forms.Label();
            this.sfLabelD = new System.Windows.Forms.Label();
            this.sfLabelC = new System.Windows.Forms.Label();
            this.sfLabelB = new System.Windows.Forms.Label();
            this.sfLabelA = new System.Windows.Forms.Label();
            this.sfLabel9 = new System.Windows.Forms.Label();
            this.sfLabel8 = new System.Windows.Forms.Label();
            this.sfLabel7 = new System.Windows.Forms.Label();
            this.sfLlabel6 = new System.Windows.Forms.Label();
            this.slLabel5 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.sfLabel4 = new System.Windows.Forms.Label();
            this.sfLabel3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.sfLabel2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.sfLabel1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.sfLabel0 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.siLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nulLabel = new System.Windows.Forms.Label();
            this.soLabel = new System.Windows.Forms.Label();
            this.tableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.AutoSize = true;
            this.tableLayoutPanel.ColumnCount = 2;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel.Controls.Add(this.sfLabelV, 1, 36);
            this.tableLayoutPanel.Controls.Add(this.sfLabelU, 1, 35);
            this.tableLayoutPanel.Controls.Add(this.sfLabelT, 1, 34);
            this.tableLayoutPanel.Controls.Add(this.sfLabelS, 1, 33);
            this.tableLayoutPanel.Controls.Add(this.sfLabelR, 1, 32);
            this.tableLayoutPanel.Controls.Add(this.sfLabelQ, 1, 31);
            this.tableLayoutPanel.Controls.Add(this.sfLabelP, 1, 30);
            this.tableLayoutPanel.Controls.Add(this.sfLabelO, 1, 29);
            this.tableLayoutPanel.Controls.Add(this.sfLabelN, 1, 28);
            this.tableLayoutPanel.Controls.Add(this.sfLabelM, 1, 27);
            this.tableLayoutPanel.Controls.Add(this.sfLabelL, 1, 26);
            this.tableLayoutPanel.Controls.Add(this.sfLabelK, 1, 25);
            this.tableLayoutPanel.Controls.Add(this.sfLabelJ, 1, 24);
            this.tableLayoutPanel.Controls.Add(this.sfLabelI, 1, 23);
            this.tableLayoutPanel.Controls.Add(this.sfLabelH, 1, 22);
            this.tableLayoutPanel.Controls.Add(this.sfLabelG, 1, 21);
            this.tableLayoutPanel.Controls.Add(this.sfLabelF, 1, 20);
            this.tableLayoutPanel.Controls.Add(this.sfLlabelE, 1, 19);
            this.tableLayoutPanel.Controls.Add(this.sfLabelD, 1, 18);
            this.tableLayoutPanel.Controls.Add(this.sfLabelC, 1, 17);
            this.tableLayoutPanel.Controls.Add(this.sfLabelB, 1, 16);
            this.tableLayoutPanel.Controls.Add(this.sfLabelA, 1, 15);
            this.tableLayoutPanel.Controls.Add(this.sfLabel9, 1, 14);
            this.tableLayoutPanel.Controls.Add(this.sfLabel8, 1, 13);
            this.tableLayoutPanel.Controls.Add(this.sfLabel7, 1, 12);
            this.tableLayoutPanel.Controls.Add(this.sfLlabel6, 1, 11);
            this.tableLayoutPanel.Controls.Add(this.slLabel5, 1, 10);
            this.tableLayoutPanel.Controls.Add(this.label43, 0, 36);
            this.tableLayoutPanel.Controls.Add(this.label42, 0, 35);
            this.tableLayoutPanel.Controls.Add(this.label41, 0, 34);
            this.tableLayoutPanel.Controls.Add(this.label40, 0, 33);
            this.tableLayoutPanel.Controls.Add(this.label39, 0, 32);
            this.tableLayoutPanel.Controls.Add(this.label38, 0, 31);
            this.tableLayoutPanel.Controls.Add(this.label37, 0, 30);
            this.tableLayoutPanel.Controls.Add(this.label36, 0, 29);
            this.tableLayoutPanel.Controls.Add(this.label35, 0, 28);
            this.tableLayoutPanel.Controls.Add(this.label34, 0, 27);
            this.tableLayoutPanel.Controls.Add(this.label33, 0, 25);
            this.tableLayoutPanel.Controls.Add(this.label32, 0, 26);
            this.tableLayoutPanel.Controls.Add(this.label31, 0, 24);
            this.tableLayoutPanel.Controls.Add(this.label30, 0, 23);
            this.tableLayoutPanel.Controls.Add(this.label29, 0, 22);
            this.tableLayoutPanel.Controls.Add(this.label28, 0, 21);
            this.tableLayoutPanel.Controls.Add(this.label27, 0, 20);
            this.tableLayoutPanel.Controls.Add(this.label26, 0, 19);
            this.tableLayoutPanel.Controls.Add(this.label25, 0, 18);
            this.tableLayoutPanel.Controls.Add(this.label24, 0, 17);
            this.tableLayoutPanel.Controls.Add(this.label23, 0, 16);
            this.tableLayoutPanel.Controls.Add(this.label22, 0, 15);
            this.tableLayoutPanel.Controls.Add(this.label21, 0, 14);
            this.tableLayoutPanel.Controls.Add(this.label20, 0, 13);
            this.tableLayoutPanel.Controls.Add(this.label19, 0, 12);
            this.tableLayoutPanel.Controls.Add(this.label18, 0, 11);
            this.tableLayoutPanel.Controls.Add(this.label17, 0, 10);
            this.tableLayoutPanel.Controls.Add(this.sfLabel4, 1, 9);
            this.tableLayoutPanel.Controls.Add(this.sfLabel3, 1, 8);
            this.tableLayoutPanel.Controls.Add(this.label16, 0, 9);
            this.tableLayoutPanel.Controls.Add(this.sfLabel2, 1, 7);
            this.tableLayoutPanel.Controls.Add(this.label14, 0, 8);
            this.tableLayoutPanel.Controls.Add(this.label11, 0, 7);
            this.tableLayoutPanel.Controls.Add(this.sfLabel1, 1, 6);
            this.tableLayoutPanel.Controls.Add(this.label9, 0, 6);
            this.tableLayoutPanel.Controls.Add(this.sfLabel0, 1, 5);
            this.tableLayoutPanel.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel.Controls.Add(this.siLabel, 1, 4);
            this.tableLayoutPanel.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.label1, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.nulLabel, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.soLabel, 1, 3);
            this.tableLayoutPanel.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel.Margin = new System.Windows.Forms.Padding(12);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 37;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(454, 705);
            this.tableLayoutPanel.TabIndex = 1;
            // 
            // sfLabelV
            // 
            this.sfLabelV.AutoSize = true;
            this.sfLabelV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelV.Location = new System.Drawing.Point(33, 684);
            this.sfLabelV.Name = "sfLabelV";
            this.sfLabelV.Size = new System.Drawing.Size(418, 21);
            this.sfLabelV.TabIndex = 12;
            this.sfLabelV.Text = "Start Field, invisible, protected, numeric, modified";
            this.sfLabelV.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelU
            // 
            this.sfLabelU.AutoSize = true;
            this.sfLabelU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelU.Location = new System.Drawing.Point(33, 664);
            this.sfLabelU.Name = "sfLabelU";
            this.sfLabelU.Size = new System.Drawing.Size(418, 20);
            this.sfLabelU.TabIndex = 12;
            this.sfLabelU.Text = "Start Field, invisible, protected, numeric";
            this.sfLabelU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelT
            // 
            this.sfLabelT.AutoSize = true;
            this.sfLabelT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelT.Location = new System.Drawing.Point(33, 644);
            this.sfLabelT.Name = "sfLabelT";
            this.sfLabelT.Size = new System.Drawing.Size(418, 20);
            this.sfLabelT.TabIndex = 12;
            this.sfLabelT.Text = "Start Field, highlighted, selectable, protected, numeric, modified";
            this.sfLabelT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelS
            // 
            this.sfLabelS.AutoSize = true;
            this.sfLabelS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelS.Location = new System.Drawing.Point(33, 624);
            this.sfLabelS.Name = "sfLabelS";
            this.sfLabelS.Size = new System.Drawing.Size(418, 20);
            this.sfLabelS.TabIndex = 12;
            this.sfLabelS.Text = "Start Field, highlighted, selectable, protected, numeric";
            this.sfLabelS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelR
            // 
            this.sfLabelR.AutoSize = true;
            this.sfLabelR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelR.Location = new System.Drawing.Point(33, 604);
            this.sfLabelR.Name = "sfLabelR";
            this.sfLabelR.Size = new System.Drawing.Size(418, 20);
            this.sfLabelR.TabIndex = 12;
            this.sfLabelR.Text = "Start Field, selectable, protected, numeric, modified";
            this.sfLabelR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelQ
            // 
            this.sfLabelQ.AutoSize = true;
            this.sfLabelQ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelQ.Location = new System.Drawing.Point(33, 584);
            this.sfLabelQ.Name = "sfLabelQ";
            this.sfLabelQ.Size = new System.Drawing.Size(418, 20);
            this.sfLabelQ.TabIndex = 12;
            this.sfLabelQ.Text = "Start Field, selectable, protected, numeric";
            this.sfLabelQ.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelP
            // 
            this.sfLabelP.AutoSize = true;
            this.sfLabelP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelP.Location = new System.Drawing.Point(33, 564);
            this.sfLabelP.Name = "sfLabelP";
            this.sfLabelP.Size = new System.Drawing.Size(418, 20);
            this.sfLabelP.TabIndex = 12;
            this.sfLabelP.Text = "Start Field, protected, numeric, modified";
            this.sfLabelP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelO
            // 
            this.sfLabelO.AutoSize = true;
            this.sfLabelO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelO.Location = new System.Drawing.Point(33, 544);
            this.sfLabelO.Name = "sfLabelO";
            this.sfLabelO.Size = new System.Drawing.Size(418, 20);
            this.sfLabelO.TabIndex = 12;
            this.sfLabelO.Text = "Start Field, protected, numeric";
            this.sfLabelO.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelN
            // 
            this.sfLabelN.AutoSize = true;
            this.sfLabelN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelN.Location = new System.Drawing.Point(33, 524);
            this.sfLabelN.Name = "sfLabelN";
            this.sfLabelN.Size = new System.Drawing.Size(418, 20);
            this.sfLabelN.TabIndex = 12;
            this.sfLabelN.Text = "Start Field, invisible, protected, modified";
            this.sfLabelN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelM
            // 
            this.sfLabelM.AutoSize = true;
            this.sfLabelM.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelM.Location = new System.Drawing.Point(33, 504);
            this.sfLabelM.Name = "sfLabelM";
            this.sfLabelM.Size = new System.Drawing.Size(418, 20);
            this.sfLabelM.TabIndex = 12;
            this.sfLabelM.Text = "Start Field, invisible, protected";
            this.sfLabelM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelL
            // 
            this.sfLabelL.AutoSize = true;
            this.sfLabelL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelL.Location = new System.Drawing.Point(33, 484);
            this.sfLabelL.Name = "sfLabelL";
            this.sfLabelL.Size = new System.Drawing.Size(418, 20);
            this.sfLabelL.TabIndex = 12;
            this.sfLabelL.Text = "Start Field, highlighted, selectable, protected, modified";
            this.sfLabelL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelK
            // 
            this.sfLabelK.AutoSize = true;
            this.sfLabelK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelK.Location = new System.Drawing.Point(33, 464);
            this.sfLabelK.Name = "sfLabelK";
            this.sfLabelK.Size = new System.Drawing.Size(418, 20);
            this.sfLabelK.TabIndex = 12;
            this.sfLabelK.Text = "Start Field, highlighted, selectable, protected";
            this.sfLabelK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelJ
            // 
            this.sfLabelJ.AutoSize = true;
            this.sfLabelJ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelJ.Location = new System.Drawing.Point(33, 444);
            this.sfLabelJ.Name = "sfLabelJ";
            this.sfLabelJ.Size = new System.Drawing.Size(418, 20);
            this.sfLabelJ.TabIndex = 12;
            this.sfLabelJ.Text = "Start Field, selectable, protected, modified";
            this.sfLabelJ.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelI
            // 
            this.sfLabelI.AutoSize = true;
            this.sfLabelI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelI.Location = new System.Drawing.Point(33, 424);
            this.sfLabelI.Name = "sfLabelI";
            this.sfLabelI.Size = new System.Drawing.Size(418, 20);
            this.sfLabelI.TabIndex = 12;
            this.sfLabelI.Text = "Start Field, selectable, protected";
            this.sfLabelI.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelH
            // 
            this.sfLabelH.AutoSize = true;
            this.sfLabelH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelH.Location = new System.Drawing.Point(33, 404);
            this.sfLabelH.Name = "sfLabelH";
            this.sfLabelH.Size = new System.Drawing.Size(418, 20);
            this.sfLabelH.TabIndex = 12;
            this.sfLabelH.Text = "Start Field, protected, modified";
            this.sfLabelH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelG
            // 
            this.sfLabelG.AutoSize = true;
            this.sfLabelG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelG.Location = new System.Drawing.Point(33, 384);
            this.sfLabelG.Name = "sfLabelG";
            this.sfLabelG.Size = new System.Drawing.Size(418, 20);
            this.sfLabelG.TabIndex = 12;
            this.sfLabelG.Text = "Start Field, protected";
            this.sfLabelG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelF
            // 
            this.sfLabelF.AutoSize = true;
            this.sfLabelF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelF.Location = new System.Drawing.Point(33, 364);
            this.sfLabelF.Name = "sfLabelF";
            this.sfLabelF.Size = new System.Drawing.Size(418, 20);
            this.sfLabelF.TabIndex = 12;
            this.sfLabelF.Text = "Start Field, invisible, numeric, modified";
            this.sfLabelF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLlabelE
            // 
            this.sfLlabelE.AutoSize = true;
            this.sfLlabelE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLlabelE.Location = new System.Drawing.Point(33, 344);
            this.sfLlabelE.Name = "sfLlabelE";
            this.sfLlabelE.Size = new System.Drawing.Size(418, 20);
            this.sfLlabelE.TabIndex = 12;
            this.sfLlabelE.Text = "Start Field, invisible, numeric";
            this.sfLlabelE.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelD
            // 
            this.sfLabelD.AutoSize = true;
            this.sfLabelD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelD.Location = new System.Drawing.Point(33, 324);
            this.sfLabelD.Name = "sfLabelD";
            this.sfLabelD.Size = new System.Drawing.Size(418, 20);
            this.sfLabelD.TabIndex = 12;
            this.sfLabelD.Text = "Start Field, highlighted, selectable, numeric, modified";
            this.sfLabelD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelC
            // 
            this.sfLabelC.AutoSize = true;
            this.sfLabelC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelC.Location = new System.Drawing.Point(33, 304);
            this.sfLabelC.Name = "sfLabelC";
            this.sfLabelC.Size = new System.Drawing.Size(418, 20);
            this.sfLabelC.TabIndex = 12;
            this.sfLabelC.Text = "Start Field, highlighted, selectable, numeric";
            this.sfLabelC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelB
            // 
            this.sfLabelB.AutoSize = true;
            this.sfLabelB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelB.Location = new System.Drawing.Point(33, 284);
            this.sfLabelB.Name = "sfLabelB";
            this.sfLabelB.Size = new System.Drawing.Size(418, 20);
            this.sfLabelB.TabIndex = 12;
            this.sfLabelB.Text = "Start Field, selectable, numeric, modified";
            this.sfLabelB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabelA
            // 
            this.sfLabelA.AutoSize = true;
            this.sfLabelA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabelA.Location = new System.Drawing.Point(33, 264);
            this.sfLabelA.Name = "sfLabelA";
            this.sfLabelA.Size = new System.Drawing.Size(418, 20);
            this.sfLabelA.TabIndex = 12;
            this.sfLabelA.Text = "Start Field, selectable, numeric";
            this.sfLabelA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabel9
            // 
            this.sfLabel9.AutoSize = true;
            this.sfLabel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel9.Location = new System.Drawing.Point(33, 244);
            this.sfLabel9.Name = "sfLabel9";
            this.sfLabel9.Size = new System.Drawing.Size(418, 20);
            this.sfLabel9.TabIndex = 12;
            this.sfLabel9.Text = "Start Field, numeric, modified";
            this.sfLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabel8
            // 
            this.sfLabel8.AutoSize = true;
            this.sfLabel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel8.Location = new System.Drawing.Point(33, 224);
            this.sfLabel8.Name = "sfLabel8";
            this.sfLabel8.Size = new System.Drawing.Size(418, 20);
            this.sfLabel8.TabIndex = 12;
            this.sfLabel8.Text = "Start Field, numeric";
            this.sfLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabel7
            // 
            this.sfLabel7.AutoSize = true;
            this.sfLabel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel7.Location = new System.Drawing.Point(33, 204);
            this.sfLabel7.Name = "sfLabel7";
            this.sfLabel7.Size = new System.Drawing.Size(418, 20);
            this.sfLabel7.TabIndex = 12;
            this.sfLabel7.Text = "Start Field, invisible, modified";
            this.sfLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLlabel6
            // 
            this.sfLlabel6.AutoSize = true;
            this.sfLlabel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLlabel6.Location = new System.Drawing.Point(33, 184);
            this.sfLlabel6.Name = "sfLlabel6";
            this.sfLlabel6.Size = new System.Drawing.Size(418, 20);
            this.sfLlabel6.TabIndex = 12;
            this.sfLlabel6.Text = "Start Field, invisible";
            this.sfLlabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // slLabel5
            // 
            this.slLabel5.AutoSize = true;
            this.slLabel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slLabel5.Location = new System.Drawing.Point(33, 164);
            this.slLabel5.Name = "slLabel5";
            this.slLabel5.Size = new System.Drawing.Size(418, 20);
            this.slLabel5.TabIndex = 12;
            this.slLabel5.Text = "Start Field, highlighted, selectable, modified";
            this.slLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Yellow;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(3, 684);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(24, 21);
            this.label43.TabIndex = 11;
            this.label43.Tag = "`";
            this.label43.Text = "V";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Yellow;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(3, 664);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(24, 20);
            this.label42.TabIndex = 11;
            this.label42.Tag = "`";
            this.label42.Text = "U";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Yellow;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(3, 644);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(24, 20);
            this.label41.TabIndex = 11;
            this.label41.Tag = "`";
            this.label41.Text = "T";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Yellow;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(3, 624);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 20);
            this.label40.TabIndex = 11;
            this.label40.Tag = "`";
            this.label40.Text = "S";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Yellow;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(3, 604);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(24, 20);
            this.label39.TabIndex = 11;
            this.label39.Tag = "`";
            this.label39.Text = "R";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Yellow;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(3, 584);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(24, 20);
            this.label38.TabIndex = 11;
            this.label38.Tag = "`";
            this.label38.Text = "Q";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Yellow;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(3, 564);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(24, 20);
            this.label37.TabIndex = 11;
            this.label37.Tag = "`";
            this.label37.Text = "P";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Yellow;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(3, 544);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(24, 20);
            this.label36.TabIndex = 11;
            this.label36.Tag = "`";
            this.label36.Text = "O";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Yellow;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(3, 524);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(24, 20);
            this.label35.TabIndex = 11;
            this.label35.Tag = "`";
            this.label35.Text = "N";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Yellow;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(3, 504);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(24, 20);
            this.label34.TabIndex = 11;
            this.label34.Tag = "`";
            this.label34.Text = "M";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Yellow;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(3, 464);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(24, 20);
            this.label33.TabIndex = 11;
            this.label33.Tag = "`";
            this.label33.Text = "K";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Yellow;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(3, 484);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(24, 20);
            this.label32.TabIndex = 11;
            this.label32.Tag = "`";
            this.label32.Text = "L";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Yellow;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(3, 444);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(24, 20);
            this.label31.TabIndex = 11;
            this.label31.Tag = "`";
            this.label31.Text = "J";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Yellow;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(3, 424);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(24, 20);
            this.label30.TabIndex = 11;
            this.label30.Tag = "`";
            this.label30.Text = "I";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Yellow;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(3, 404);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(24, 20);
            this.label29.TabIndex = 11;
            this.label29.Tag = "`";
            this.label29.Text = "H";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Yellow;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(3, 384);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(24, 20);
            this.label28.TabIndex = 11;
            this.label28.Tag = "`";
            this.label28.Text = "G";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Yellow;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(3, 364);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(24, 20);
            this.label27.TabIndex = 11;
            this.label27.Tag = "`";
            this.label27.Text = "F";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Yellow;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(3, 344);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 20);
            this.label26.TabIndex = 11;
            this.label26.Tag = "`";
            this.label26.Text = "E";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Yellow;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(3, 324);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(24, 20);
            this.label25.TabIndex = 11;
            this.label25.Tag = "`";
            this.label25.Text = "D";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Yellow;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(3, 304);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(24, 20);
            this.label24.TabIndex = 11;
            this.label24.Tag = "`";
            this.label24.Text = "C";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Yellow;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(3, 284);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(24, 20);
            this.label23.TabIndex = 11;
            this.label23.Tag = "`";
            this.label23.Text = "B";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Yellow;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(3, 264);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(24, 20);
            this.label22.TabIndex = 11;
            this.label22.Tag = "`";
            this.label22.Text = "A";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Yellow;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(3, 244);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(24, 20);
            this.label21.TabIndex = 11;
            this.label21.Tag = "`";
            this.label21.Text = "9";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Yellow;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(3, 224);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(24, 20);
            this.label20.TabIndex = 11;
            this.label20.Tag = "`";
            this.label20.Text = "8";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Yellow;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(3, 204);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 20);
            this.label19.TabIndex = 11;
            this.label19.Tag = "`";
            this.label19.Text = "7";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Yellow;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(3, 184);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 20);
            this.label18.TabIndex = 12;
            this.label18.Tag = "`";
            this.label18.Text = "6";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Yellow;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(3, 164);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 20);
            this.label17.TabIndex = 11;
            this.label17.Tag = "`";
            this.label17.Text = "5";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfLabel4
            // 
            this.sfLabel4.AutoSize = true;
            this.sfLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel4.Location = new System.Drawing.Point(33, 144);
            this.sfLabel4.Name = "sfLabel4";
            this.sfLabel4.Size = new System.Drawing.Size(418, 20);
            this.sfLabel4.TabIndex = 11;
            this.sfLabel4.Text = "Start Field, highlighted, selectable";
            this.sfLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sfLabel3
            // 
            this.sfLabel3.AutoSize = true;
            this.sfLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel3.Location = new System.Drawing.Point(33, 124);
            this.sfLabel3.Name = "sfLabel3";
            this.sfLabel3.Size = new System.Drawing.Size(418, 20);
            this.sfLabel3.TabIndex = 9;
            this.sfLabel3.Text = "Start Field, selectable, modified";
            this.sfLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Yellow;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(3, 144);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 20);
            this.label16.TabIndex = 10;
            this.label16.Tag = "`";
            this.label16.Text = "4";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfLabel2
            // 
            this.sfLabel2.AutoSize = true;
            this.sfLabel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel2.Location = new System.Drawing.Point(33, 104);
            this.sfLabel2.Name = "sfLabel2";
            this.sfLabel2.Size = new System.Drawing.Size(418, 20);
            this.sfLabel2.TabIndex = 7;
            this.sfLabel2.Text = "Start Field, selectable";
            this.sfLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Yellow;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(3, 124);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 20);
            this.label14.TabIndex = 8;
            this.label14.Tag = "`";
            this.label14.Text = "3";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Yellow;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(3, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 20);
            this.label11.TabIndex = 5;
            this.label11.Tag = "`";
            this.label11.Text = "2";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfLabel1
            // 
            this.sfLabel1.AutoSize = true;
            this.sfLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel1.Location = new System.Drawing.Point(33, 84);
            this.sfLabel1.Name = "sfLabel1";
            this.sfLabel1.Size = new System.Drawing.Size(418, 20);
            this.sfLabel1.TabIndex = 6;
            this.sfLabel1.Text = "Start Field, modified";
            this.sfLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Yellow;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 20);
            this.label9.TabIndex = 4;
            this.label9.Tag = "`";
            this.label9.Text = "1";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sfLabel0
            // 
            this.sfLabel0.AutoSize = true;
            this.sfLabel0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfLabel0.Location = new System.Drawing.Point(33, 64);
            this.sfLabel0.Name = "sfLabel0";
            this.sfLabel0.Size = new System.Drawing.Size(418, 20);
            this.sfLabel0.TabIndex = 5;
            this.sfLabel0.Text = "Start Field, default (visible; not protected, highlighted, selectable, numeric or" +
    " modified)";
            this.sfLabel0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Yellow;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 20);
            this.label7.TabIndex = 3;
            this.label7.Tag = "`";
            this.label7.Text = "0";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // siLabel
            // 
            this.siLabel.AutoSize = true;
            this.siLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.siLabel.Location = new System.Drawing.Point(33, 44);
            this.siLabel.Name = "siLabel";
            this.siLabel.Size = new System.Drawing.Size(418, 20);
            this.siLabel.TabIndex = 4;
            this.siLabel.Text = "SI (shift to SBCS), X\'0F\'";
            this.siLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(3, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 20);
            this.label4.TabIndex = 2;
            this.label4.Tag = "`";
            this.label4.Text = ">";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label3.Location = new System.Drawing.Point(3, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 20);
            this.label3.TabIndex = 2;
            this.label3.Tag = "`";
            this.label3.Text = "<";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 20);
            this.label1.TabIndex = 0;
            this.label1.Tag = "`";
            this.label1.Text = ".";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nulLabel
            // 
            this.nulLabel.AutoSize = true;
            this.nulLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nulLabel.Location = new System.Drawing.Point(33, 4);
            this.nulLabel.Name = "nulLabel";
            this.nulLabel.Size = new System.Drawing.Size(418, 20);
            this.nulLabel.TabIndex = 1;
            this.nulLabel.Text = "NUL, X\'00\'";
            this.nulLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // soLabel
            // 
            this.soLabel.AutoSize = true;
            this.soLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.soLabel.Location = new System.Drawing.Point(33, 24);
            this.soLabel.Name = "soLabel";
            this.soLabel.Size = new System.Drawing.Size(418, 20);
            this.soLabel.TabIndex = 3;
            this.soLabel.Text = "SO (shift to DBCS), X\'0E\'";
            this.soLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // VisibleControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(483, 736);
            this.Controls.Add(this.tableLayoutPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "VisibleControls";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Visible Control Characters";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.VisibleControls_FormClosing);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.Label siLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nulLabel;
        private System.Windows.Forms.Label soLabel;
        private System.Windows.Forms.Label sfLabelV;
        private System.Windows.Forms.Label sfLabelU;
        private System.Windows.Forms.Label sfLabelT;
        private System.Windows.Forms.Label sfLabelS;
        private System.Windows.Forms.Label sfLabelR;
        private System.Windows.Forms.Label sfLabelQ;
        private System.Windows.Forms.Label sfLabelP;
        private System.Windows.Forms.Label sfLabelO;
        private System.Windows.Forms.Label sfLabelN;
        private System.Windows.Forms.Label sfLabelM;
        private System.Windows.Forms.Label sfLabelL;
        private System.Windows.Forms.Label sfLabelK;
        private System.Windows.Forms.Label sfLabelJ;
        private System.Windows.Forms.Label sfLabelI;
        private System.Windows.Forms.Label sfLabelH;
        private System.Windows.Forms.Label sfLabelG;
        private System.Windows.Forms.Label sfLabelF;
        private System.Windows.Forms.Label sfLlabelE;
        private System.Windows.Forms.Label sfLabelD;
        private System.Windows.Forms.Label sfLabelC;
        private System.Windows.Forms.Label sfLabelB;
        private System.Windows.Forms.Label sfLabelA;
        private System.Windows.Forms.Label sfLabel9;
        private System.Windows.Forms.Label sfLabel8;
        private System.Windows.Forms.Label sfLabel7;
        private System.Windows.Forms.Label sfLlabel6;
        private System.Windows.Forms.Label slLabel5;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label sfLabel4;
        private System.Windows.Forms.Label sfLabel3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label sfLabel2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label sfLabel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label sfLabel0;
        private System.Windows.Forms.Label label7;
    }
}