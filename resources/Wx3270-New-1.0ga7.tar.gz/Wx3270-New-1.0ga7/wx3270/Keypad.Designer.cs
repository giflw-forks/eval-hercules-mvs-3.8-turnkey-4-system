﻿namespace Wx3270
{
    partial class Keypad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Keypad));
            this.KeypadPanel = new System.Windows.Forms.TableLayoutPanel();
            this.newLeftPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ResetPanel = new System.Windows.Forms.Panel();
            this.ResetButton = new Wx3270.NoSelectButton();
            this.pa2Panel = new System.Windows.Forms.Panel();
            this.PA2button = new Wx3270.NoSelectButton();
            this.pa1Panel = new System.Windows.Forms.Panel();
            this.PA1button = new Wx3270.NoSelectButton();
            this.pf12Panel = new System.Windows.Forms.Panel();
            this.PF12button = new Wx3270.NoSelectButton();
            this.pf11Panel = new System.Windows.Forms.Panel();
            this.PF11button = new Wx3270.NoSelectButton();
            this.pa10Panel = new System.Windows.Forms.Panel();
            this.PF10button = new Wx3270.NoSelectButton();
            this.pf9Panel = new System.Windows.Forms.Panel();
            this.PF9button = new Wx3270.NoSelectButton();
            this.pf8Panel = new System.Windows.Forms.Panel();
            this.PF8button = new Wx3270.NoSelectButton();
            this.pf7Panel = new System.Windows.Forms.Panel();
            this.PF7button = new Wx3270.NoSelectButton();
            this.pf6Panel = new System.Windows.Forms.Panel();
            this.PF6button = new Wx3270.NoSelectButton();
            this.pf5Panel = new System.Windows.Forms.Panel();
            this.PF5button = new Wx3270.NoSelectButton();
            this.pf4Panel = new System.Windows.Forms.Panel();
            this.PF4button = new Wx3270.NoSelectButton();
            this.pf3Panel = new System.Windows.Forms.Panel();
            this.PF3button = new Wx3270.NoSelectButton();
            this.pf1Panel = new System.Windows.Forms.Panel();
            this.PF1button = new Wx3270.NoSelectButton();
            this.pf2Panel = new System.Windows.Forms.Panel();
            this.PF2button = new Wx3270.NoSelectButton();
            this.newMiddlePanel = new System.Windows.Forms.TableLayoutPanel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.BackTabButton = new Wx3270.NoSelectButton();
            this.tabPanel = new System.Windows.Forms.Panel();
            this.TabButton = new Wx3270.NoSelectButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.BlankButton9 = new Wx3270.NoSelectButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.BlankButton7 = new Wx3270.NoSelectButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.BlankButton5 = new Wx3270.NoSelectButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Blank1Buton = new Wx3270.NoSelectButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BlankButton8 = new Wx3270.NoSelectButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.BlankButton6 = new Wx3270.NoSelectButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BlankButton4 = new Wx3270.NoSelectButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Blank2Button = new Wx3270.NoSelectButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.NotButton = new Wx3270.NoSelectButton();
            this.enterPanel = new System.Windows.Forms.Panel();
            this.EnterButton = new Wx3270.NoSelectButton();
            this.newlinePanel = new System.Windows.Forms.Panel();
            this.NewlineButton = new Wx3270.NoSelectButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.BlankButton3 = new Wx3270.NoSelectButton();
            this.newRightPanel = new System.Windows.Forms.TableLayoutPanel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.RightButton = new Wx3270.NoSelectButton();
            this.downPanel = new System.Windows.Forms.Panel();
            this.DownButton = new Wx3270.NoSelectButton();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.LeftButton = new Wx3270.NoSelectButton();
            this.deletePanel = new System.Windows.Forms.Panel();
            this.DeleteButton = new Wx3270.NoSelectButton();
            this.upPanel = new System.Windows.Forms.Panel();
            this.UpButton = new Wx3270.NoSelectButton();
            this.insertPanel = new System.Windows.Forms.Panel();
            this.InsertButton = new Wx3270.NoSelectButton();
            this.sysReqPanel = new System.Windows.Forms.Panel();
            this.SysReqButton = new Wx3270.NoSelectButton();
            this.cursorBlinkPanel = new System.Windows.Forms.Panel();
            this.CursorBlinkButton = new Wx3270.NoSelectButton();
            this.attnPanel = new System.Windows.Forms.Panel();
            this.AttnButton = new Wx3270.NoSelectButton();
            this.fieldMarkPanel = new System.Windows.Forms.Panel();
            this.FieldMarkButton = new Wx3270.NoSelectButton();
            this.dupPanel = new System.Windows.Forms.Panel();
            this.DupButton = new Wx3270.NoSelectButton();
            this.eraseEofPanel = new System.Windows.Forms.Panel();
            this.EraseEOFbutton = new Wx3270.NoSelectButton();
            this.clearPanel = new System.Windows.Forms.Panel();
            this.ClearButton = new Wx3270.NoSelectButton();
            this.cursorSelectPanel = new System.Windows.Forms.Panel();
            this.CursorSelectButton = new Wx3270.NoSelectButton();
            this.eraseInputPanel = new System.Windows.Forms.Panel();
            this.EraseInputButton = new Wx3270.NoSelectButton();
            this.keypadOuterPanel = new System.Windows.Forms.Panel();
            this.KeypadPanel.SuspendLayout();
            this.newLeftPanel.SuspendLayout();
            this.ResetPanel.SuspendLayout();
            this.pa2Panel.SuspendLayout();
            this.pa1Panel.SuspendLayout();
            this.pf12Panel.SuspendLayout();
            this.pf11Panel.SuspendLayout();
            this.pa10Panel.SuspendLayout();
            this.pf9Panel.SuspendLayout();
            this.pf8Panel.SuspendLayout();
            this.pf7Panel.SuspendLayout();
            this.pf6Panel.SuspendLayout();
            this.pf5Panel.SuspendLayout();
            this.pf4Panel.SuspendLayout();
            this.pf3Panel.SuspendLayout();
            this.pf1Panel.SuspendLayout();
            this.pf2Panel.SuspendLayout();
            this.newMiddlePanel.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tabPanel.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.enterPanel.SuspendLayout();
            this.newlinePanel.SuspendLayout();
            this.panel7.SuspendLayout();
            this.newRightPanel.SuspendLayout();
            this.rightPanel.SuspendLayout();
            this.downPanel.SuspendLayout();
            this.leftPanel.SuspendLayout();
            this.deletePanel.SuspendLayout();
            this.upPanel.SuspendLayout();
            this.insertPanel.SuspendLayout();
            this.sysReqPanel.SuspendLayout();
            this.cursorBlinkPanel.SuspendLayout();
            this.attnPanel.SuspendLayout();
            this.fieldMarkPanel.SuspendLayout();
            this.dupPanel.SuspendLayout();
            this.eraseEofPanel.SuspendLayout();
            this.clearPanel.SuspendLayout();
            this.cursorSelectPanel.SuspendLayout();
            this.eraseInputPanel.SuspendLayout();
            this.keypadOuterPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // KeypadPanel
            // 
            this.KeypadPanel.AutoSize = true;
            this.KeypadPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.KeypadPanel.BackColor = System.Drawing.SystemColors.Control;
            this.KeypadPanel.ColumnCount = 5;
            this.KeypadPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.KeypadPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.KeypadPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.KeypadPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.KeypadPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.KeypadPanel.Controls.Add(this.newLeftPanel, 0, 0);
            this.KeypadPanel.Controls.Add(this.newMiddlePanel, 2, 0);
            this.KeypadPanel.Controls.Add(this.newRightPanel, 4, 0);
            this.KeypadPanel.Location = new System.Drawing.Point(0, 0);
            this.KeypadPanel.Margin = new System.Windows.Forms.Padding(0);
            this.KeypadPanel.Name = "KeypadPanel";
            this.KeypadPanel.RowCount = 1;
            this.KeypadPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.KeypadPanel.Size = new System.Drawing.Size(476, 240);
            this.KeypadPanel.TabIndex = 36;
            // 
            // newLeftPanel
            // 
            this.newLeftPanel.AutoSize = true;
            this.newLeftPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.newLeftPanel.BackColor = System.Drawing.Color.Black;
            this.newLeftPanel.ColumnCount = 3;
            this.newLeftPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newLeftPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newLeftPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newLeftPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.newLeftPanel.Controls.Add(this.ResetPanel, 2, 4);
            this.newLeftPanel.Controls.Add(this.pa2Panel, 1, 4);
            this.newLeftPanel.Controls.Add(this.pa1Panel, 0, 4);
            this.newLeftPanel.Controls.Add(this.pf12Panel, 2, 3);
            this.newLeftPanel.Controls.Add(this.pf11Panel, 1, 3);
            this.newLeftPanel.Controls.Add(this.pa10Panel, 0, 3);
            this.newLeftPanel.Controls.Add(this.pf9Panel, 2, 2);
            this.newLeftPanel.Controls.Add(this.pf8Panel, 1, 2);
            this.newLeftPanel.Controls.Add(this.pf7Panel, 0, 2);
            this.newLeftPanel.Controls.Add(this.pf6Panel, 2, 1);
            this.newLeftPanel.Controls.Add(this.pf5Panel, 1, 1);
            this.newLeftPanel.Controls.Add(this.pf4Panel, 0, 1);
            this.newLeftPanel.Controls.Add(this.pf3Panel, 2, 0);
            this.newLeftPanel.Controls.Add(this.pf1Panel, 0, 0);
            this.newLeftPanel.Controls.Add(this.pf2Panel, 1, 0);
            this.newLeftPanel.Location = new System.Drawing.Point(0, 0);
            this.newLeftPanel.Margin = new System.Windows.Forms.Padding(0);
            this.newLeftPanel.Name = "newLeftPanel";
            this.newLeftPanel.RowCount = 5;
            this.newLeftPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newLeftPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newLeftPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newLeftPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newLeftPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newLeftPanel.Size = new System.Drawing.Size(144, 240);
            this.newLeftPanel.TabIndex = 0;
            // 
            // ResetPanel
            // 
            this.ResetPanel.BackColor = System.Drawing.Color.Black;
            this.ResetPanel.Controls.Add(this.ResetButton);
            this.ResetPanel.Location = new System.Drawing.Point(96, 192);
            this.ResetPanel.Margin = new System.Windows.Forms.Padding(0);
            this.ResetPanel.Name = "ResetPanel";
            this.ResetPanel.Size = new System.Drawing.Size(48, 48);
            this.ResetPanel.TabIndex = 39;
            // 
            // ResetButton
            // 
            this.ResetButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.ResetButton.FlatAppearance.BorderSize = 0;
            this.ResetButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.ForeColor = System.Drawing.Color.DarkGray;
            this.ResetButton.Location = new System.Drawing.Point(0, 0);
            this.ResetButton.Margin = new System.Windows.Forms.Padding(0);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(48, 48);
            this.ResetButton.TabIndex = 34;
            this.ResetButton.TabStop = false;
            this.ResetButton.Tag = "";
            this.ResetButton.Text = "RESET";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.ResetButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pa2Panel
            // 
            this.pa2Panel.BackColor = System.Drawing.Color.Black;
            this.pa2Panel.Controls.Add(this.PA2button);
            this.pa2Panel.Location = new System.Drawing.Point(48, 192);
            this.pa2Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pa2Panel.Name = "pa2Panel";
            this.pa2Panel.Size = new System.Drawing.Size(48, 48);
            this.pa2Panel.TabIndex = 39;
            // 
            // PA2button
            // 
            this.PA2button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PA2button.FlatAppearance.BorderSize = 0;
            this.PA2button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PA2button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PA2button.ForeColor = System.Drawing.Color.DarkGray;
            this.PA2button.Location = new System.Drawing.Point(0, 0);
            this.PA2button.Margin = new System.Windows.Forms.Padding(0);
            this.PA2button.Name = "PA2button";
            this.PA2button.Size = new System.Drawing.Size(48, 48);
            this.PA2button.TabIndex = 30;
            this.PA2button.TabStop = false;
            this.PA2button.Tag = "";
            this.PA2button.Text = "PA2";
            this.PA2button.UseVisualStyleBackColor = true;
            this.PA2button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PA2button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pa1Panel
            // 
            this.pa1Panel.BackColor = System.Drawing.Color.Black;
            this.pa1Panel.Controls.Add(this.PA1button);
            this.pa1Panel.Location = new System.Drawing.Point(0, 192);
            this.pa1Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pa1Panel.Name = "pa1Panel";
            this.pa1Panel.Size = new System.Drawing.Size(48, 48);
            this.pa1Panel.TabIndex = 39;
            // 
            // PA1button
            // 
            this.PA1button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PA1button.FlatAppearance.BorderSize = 0;
            this.PA1button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PA1button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PA1button.ForeColor = System.Drawing.Color.DarkGray;
            this.PA1button.Location = new System.Drawing.Point(0, 0);
            this.PA1button.Margin = new System.Windows.Forms.Padding(0);
            this.PA1button.Name = "PA1button";
            this.PA1button.Size = new System.Drawing.Size(48, 48);
            this.PA1button.TabIndex = 29;
            this.PA1button.TabStop = false;
            this.PA1button.Tag = "";
            this.PA1button.Text = "PA1";
            this.PA1button.UseVisualStyleBackColor = true;
            this.PA1button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PA1button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf12Panel
            // 
            this.pf12Panel.BackColor = System.Drawing.Color.Black;
            this.pf12Panel.Controls.Add(this.PF12button);
            this.pf12Panel.Location = new System.Drawing.Point(96, 144);
            this.pf12Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf12Panel.Name = "pf12Panel";
            this.pf12Panel.Size = new System.Drawing.Size(48, 48);
            this.pf12Panel.TabIndex = 39;
            // 
            // PF12button
            // 
            this.PF12button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF12button.FlatAppearance.BorderSize = 0;
            this.PF12button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF12button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF12button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF12button.Location = new System.Drawing.Point(0, 0);
            this.PF12button.Margin = new System.Windows.Forms.Padding(0);
            this.PF12button.Name = "PF12button";
            this.PF12button.Size = new System.Drawing.Size(48, 48);
            this.PF12button.TabIndex = 17;
            this.PF12button.TabStop = false;
            this.PF12button.Tag = "";
            this.PF12button.Text = "PF12";
            this.PF12button.UseVisualStyleBackColor = true;
            this.PF12button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF12button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf11Panel
            // 
            this.pf11Panel.BackColor = System.Drawing.Color.Black;
            this.pf11Panel.Controls.Add(this.PF11button);
            this.pf11Panel.Location = new System.Drawing.Point(48, 144);
            this.pf11Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf11Panel.Name = "pf11Panel";
            this.pf11Panel.Size = new System.Drawing.Size(48, 48);
            this.pf11Panel.TabIndex = 39;
            // 
            // PF11button
            // 
            this.PF11button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF11button.FlatAppearance.BorderSize = 0;
            this.PF11button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF11button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF11button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF11button.Location = new System.Drawing.Point(0, 0);
            this.PF11button.Margin = new System.Windows.Forms.Padding(0);
            this.PF11button.Name = "PF11button";
            this.PF11button.Size = new System.Drawing.Size(48, 48);
            this.PF11button.TabIndex = 16;
            this.PF11button.TabStop = false;
            this.PF11button.Tag = "";
            this.PF11button.Text = "PF11";
            this.PF11button.UseVisualStyleBackColor = true;
            this.PF11button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF11button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pa10Panel
            // 
            this.pa10Panel.BackColor = System.Drawing.Color.Black;
            this.pa10Panel.Controls.Add(this.PF10button);
            this.pa10Panel.Location = new System.Drawing.Point(0, 144);
            this.pa10Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pa10Panel.Name = "pa10Panel";
            this.pa10Panel.Size = new System.Drawing.Size(48, 48);
            this.pa10Panel.TabIndex = 39;
            // 
            // PF10button
            // 
            this.PF10button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF10button.FlatAppearance.BorderSize = 0;
            this.PF10button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF10button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF10button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF10button.Location = new System.Drawing.Point(0, 0);
            this.PF10button.Margin = new System.Windows.Forms.Padding(0);
            this.PF10button.Name = "PF10button";
            this.PF10button.Size = new System.Drawing.Size(48, 48);
            this.PF10button.TabIndex = 15;
            this.PF10button.TabStop = false;
            this.PF10button.Tag = "";
            this.PF10button.Text = "PF10";
            this.PF10button.UseVisualStyleBackColor = true;
            this.PF10button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF10button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf9Panel
            // 
            this.pf9Panel.BackColor = System.Drawing.Color.Black;
            this.pf9Panel.Controls.Add(this.PF9button);
            this.pf9Panel.Location = new System.Drawing.Point(96, 96);
            this.pf9Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf9Panel.Name = "pf9Panel";
            this.pf9Panel.Size = new System.Drawing.Size(48, 48);
            this.pf9Panel.TabIndex = 39;
            // 
            // PF9button
            // 
            this.PF9button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF9button.FlatAppearance.BorderSize = 0;
            this.PF9button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF9button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF9button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF9button.Location = new System.Drawing.Point(0, 0);
            this.PF9button.Margin = new System.Windows.Forms.Padding(0);
            this.PF9button.Name = "PF9button";
            this.PF9button.Size = new System.Drawing.Size(48, 48);
            this.PF9button.TabIndex = 22;
            this.PF9button.TabStop = false;
            this.PF9button.Tag = "";
            this.PF9button.Text = "PF9";
            this.PF9button.UseVisualStyleBackColor = true;
            this.PF9button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF9button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf8Panel
            // 
            this.pf8Panel.BackColor = System.Drawing.Color.Black;
            this.pf8Panel.Controls.Add(this.PF8button);
            this.pf8Panel.Location = new System.Drawing.Point(48, 96);
            this.pf8Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf8Panel.Name = "pf8Panel";
            this.pf8Panel.Size = new System.Drawing.Size(48, 48);
            this.pf8Panel.TabIndex = 39;
            // 
            // PF8button
            // 
            this.PF8button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF8button.FlatAppearance.BorderSize = 0;
            this.PF8button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF8button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF8button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF8button.Location = new System.Drawing.Point(0, 0);
            this.PF8button.Margin = new System.Windows.Forms.Padding(0);
            this.PF8button.Name = "PF8button";
            this.PF8button.Size = new System.Drawing.Size(48, 48);
            this.PF8button.TabIndex = 21;
            this.PF8button.TabStop = false;
            this.PF8button.Tag = "";
            this.PF8button.Text = "PF8";
            this.PF8button.UseVisualStyleBackColor = true;
            this.PF8button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF8button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf7Panel
            // 
            this.pf7Panel.BackColor = System.Drawing.Color.Black;
            this.pf7Panel.Controls.Add(this.PF7button);
            this.pf7Panel.Location = new System.Drawing.Point(0, 96);
            this.pf7Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf7Panel.Name = "pf7Panel";
            this.pf7Panel.Size = new System.Drawing.Size(48, 48);
            this.pf7Panel.TabIndex = 39;
            // 
            // PF7button
            // 
            this.PF7button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF7button.FlatAppearance.BorderSize = 0;
            this.PF7button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF7button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF7button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF7button.Location = new System.Drawing.Point(0, 0);
            this.PF7button.Margin = new System.Windows.Forms.Padding(0);
            this.PF7button.Name = "PF7button";
            this.PF7button.Size = new System.Drawing.Size(48, 48);
            this.PF7button.TabIndex = 20;
            this.PF7button.TabStop = false;
            this.PF7button.Tag = "";
            this.PF7button.Text = "PF7";
            this.PF7button.UseVisualStyleBackColor = true;
            this.PF7button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF7button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf6Panel
            // 
            this.pf6Panel.BackColor = System.Drawing.Color.Black;
            this.pf6Panel.Controls.Add(this.PF6button);
            this.pf6Panel.Location = new System.Drawing.Point(96, 48);
            this.pf6Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf6Panel.Name = "pf6Panel";
            this.pf6Panel.Size = new System.Drawing.Size(48, 48);
            this.pf6Panel.TabIndex = 39;
            // 
            // PF6button
            // 
            this.PF6button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF6button.FlatAppearance.BorderSize = 0;
            this.PF6button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF6button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF6button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF6button.Location = new System.Drawing.Point(0, 0);
            this.PF6button.Margin = new System.Windows.Forms.Padding(0);
            this.PF6button.Name = "PF6button";
            this.PF6button.Size = new System.Drawing.Size(48, 48);
            this.PF6button.TabIndex = 19;
            this.PF6button.TabStop = false;
            this.PF6button.Tag = "";
            this.PF6button.Text = "PF6";
            this.PF6button.UseVisualStyleBackColor = true;
            this.PF6button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF6button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf5Panel
            // 
            this.pf5Panel.BackColor = System.Drawing.Color.Black;
            this.pf5Panel.Controls.Add(this.PF5button);
            this.pf5Panel.Location = new System.Drawing.Point(48, 48);
            this.pf5Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf5Panel.Name = "pf5Panel";
            this.pf5Panel.Size = new System.Drawing.Size(48, 48);
            this.pf5Panel.TabIndex = 39;
            // 
            // PF5button
            // 
            this.PF5button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF5button.FlatAppearance.BorderSize = 0;
            this.PF5button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF5button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF5button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF5button.Location = new System.Drawing.Point(0, 0);
            this.PF5button.Margin = new System.Windows.Forms.Padding(0);
            this.PF5button.Name = "PF5button";
            this.PF5button.Size = new System.Drawing.Size(48, 48);
            this.PF5button.TabIndex = 18;
            this.PF5button.TabStop = false;
            this.PF5button.Tag = "";
            this.PF5button.Text = "PF5";
            this.PF5button.UseVisualStyleBackColor = true;
            this.PF5button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF5button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf4Panel
            // 
            this.pf4Panel.BackColor = System.Drawing.Color.Black;
            this.pf4Panel.Controls.Add(this.PF4button);
            this.pf4Panel.Location = new System.Drawing.Point(0, 48);
            this.pf4Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf4Panel.Name = "pf4Panel";
            this.pf4Panel.Size = new System.Drawing.Size(48, 48);
            this.pf4Panel.TabIndex = 39;
            // 
            // PF4button
            // 
            this.PF4button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF4button.FlatAppearance.BorderSize = 0;
            this.PF4button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF4button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF4button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF4button.Location = new System.Drawing.Point(0, 0);
            this.PF4button.Margin = new System.Windows.Forms.Padding(0);
            this.PF4button.Name = "PF4button";
            this.PF4button.Size = new System.Drawing.Size(48, 48);
            this.PF4button.TabIndex = 14;
            this.PF4button.TabStop = false;
            this.PF4button.Tag = "";
            this.PF4button.Text = "PF4";
            this.PF4button.UseVisualStyleBackColor = true;
            this.PF4button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF4button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf3Panel
            // 
            this.pf3Panel.BackColor = System.Drawing.Color.Black;
            this.pf3Panel.Controls.Add(this.PF3button);
            this.pf3Panel.Location = new System.Drawing.Point(96, 0);
            this.pf3Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf3Panel.Name = "pf3Panel";
            this.pf3Panel.Size = new System.Drawing.Size(48, 48);
            this.pf3Panel.TabIndex = 39;
            // 
            // PF3button
            // 
            this.PF3button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF3button.FlatAppearance.BorderSize = 0;
            this.PF3button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF3button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF3button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF3button.Location = new System.Drawing.Point(0, 0);
            this.PF3button.Margin = new System.Windows.Forms.Padding(0);
            this.PF3button.Name = "PF3button";
            this.PF3button.Size = new System.Drawing.Size(48, 48);
            this.PF3button.TabIndex = 13;
            this.PF3button.TabStop = false;
            this.PF3button.Tag = "";
            this.PF3button.Text = "PF3";
            this.PF3button.UseVisualStyleBackColor = true;
            this.PF3button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF3button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf1Panel
            // 
            this.pf1Panel.BackColor = System.Drawing.Color.Black;
            this.pf1Panel.Controls.Add(this.PF1button);
            this.pf1Panel.Location = new System.Drawing.Point(0, 0);
            this.pf1Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf1Panel.Name = "pf1Panel";
            this.pf1Panel.Size = new System.Drawing.Size(48, 48);
            this.pf1Panel.TabIndex = 37;
            // 
            // PF1button
            // 
            this.PF1button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF1button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.PF1button.FlatAppearance.BorderSize = 0;
            this.PF1button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.PF1button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.PF1button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF1button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF1button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF1button.Location = new System.Drawing.Point(0, 0);
            this.PF1button.Margin = new System.Windows.Forms.Padding(0);
            this.PF1button.Name = "PF1button";
            this.PF1button.Size = new System.Drawing.Size(48, 48);
            this.PF1button.TabIndex = 0;
            this.PF1button.TabStop = false;
            this.PF1button.Tag = "";
            this.PF1button.Text = "PF1";
            this.PF1button.UseVisualStyleBackColor = true;
            this.PF1button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF1button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // pf2Panel
            // 
            this.pf2Panel.BackColor = System.Drawing.Color.Black;
            this.pf2Panel.Controls.Add(this.PF2button);
            this.pf2Panel.Location = new System.Drawing.Point(48, 0);
            this.pf2Panel.Margin = new System.Windows.Forms.Padding(0);
            this.pf2Panel.Name = "pf2Panel";
            this.pf2Panel.Size = new System.Drawing.Size(48, 48);
            this.pf2Panel.TabIndex = 37;
            // 
            // PF2button
            // 
            this.PF2button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.PF2button.FlatAppearance.BorderSize = 0;
            this.PF2button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PF2button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PF2button.ForeColor = System.Drawing.Color.DarkGray;
            this.PF2button.Location = new System.Drawing.Point(0, 0);
            this.PF2button.Margin = new System.Windows.Forms.Padding(0);
            this.PF2button.Name = "PF2button";
            this.PF2button.Size = new System.Drawing.Size(48, 48);
            this.PF2button.TabIndex = 12;
            this.PF2button.TabStop = false;
            this.PF2button.Tag = "";
            this.PF2button.Text = "PF2";
            this.PF2button.UseVisualStyleBackColor = true;
            this.PF2button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.PF2button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // newMiddlePanel
            // 
            this.newMiddlePanel.AutoSize = true;
            this.newMiddlePanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.newMiddlePanel.BackColor = System.Drawing.Color.Black;
            this.newMiddlePanel.ColumnCount = 3;
            this.newMiddlePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newMiddlePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newMiddlePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newMiddlePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.newMiddlePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.newMiddlePanel.Controls.Add(this.panel17, 2, 1);
            this.newMiddlePanel.Controls.Add(this.tabPanel, 2, 0);
            this.newMiddlePanel.Controls.Add(this.panel10, 1, 4);
            this.newMiddlePanel.Controls.Add(this.panel9, 1, 3);
            this.newMiddlePanel.Controls.Add(this.panel8, 1, 2);
            this.newMiddlePanel.Controls.Add(this.panel6, 1, 0);
            this.newMiddlePanel.Controls.Add(this.panel5, 0, 4);
            this.newMiddlePanel.Controls.Add(this.panel4, 0, 3);
            this.newMiddlePanel.Controls.Add(this.panel3, 0, 2);
            this.newMiddlePanel.Controls.Add(this.panel2, 0, 1);
            this.newMiddlePanel.Controls.Add(this.panel1, 0, 0);
            this.newMiddlePanel.Controls.Add(this.enterPanel, 2, 4);
            this.newMiddlePanel.Controls.Add(this.newlinePanel, 2, 2);
            this.newMiddlePanel.Controls.Add(this.panel7, 1, 1);
            this.newMiddlePanel.Location = new System.Drawing.Point(154, 0);
            this.newMiddlePanel.Margin = new System.Windows.Forms.Padding(0);
            this.newMiddlePanel.Name = "newMiddlePanel";
            this.newMiddlePanel.RowCount = 5;
            this.newMiddlePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newMiddlePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newMiddlePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newMiddlePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newMiddlePanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newMiddlePanel.Size = new System.Drawing.Size(168, 240);
            this.newMiddlePanel.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Controls.Add(this.BackTabButton);
            this.panel17.Location = new System.Drawing.Point(96, 48);
            this.panel17.Margin = new System.Windows.Forms.Padding(0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(72, 48);
            this.panel17.TabIndex = 42;
            // 
            // BackTabButton
            // 
            this.BackTabButton.BackgroundImage = global::Wx3270.Properties.Resources.BlankWide48;
            this.BackTabButton.FlatAppearance.BorderSize = 0;
            this.BackTabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackTabButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackTabButton.ForeColor = System.Drawing.Color.DarkGray;
            this.BackTabButton.Location = new System.Drawing.Point(0, 0);
            this.BackTabButton.Margin = new System.Windows.Forms.Padding(0);
            this.BackTabButton.Name = "BackTabButton";
            this.BackTabButton.Size = new System.Drawing.Size(72, 48);
            this.BackTabButton.TabIndex = 7;
            this.BackTabButton.TabStop = false;
            this.BackTabButton.Tag = "";
            this.BackTabButton.Text = "|←";
            this.BackTabButton.UseVisualStyleBackColor = true;
            this.BackTabButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BackTabButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // tabPanel
            // 
            this.tabPanel.BackColor = System.Drawing.Color.Black;
            this.tabPanel.Controls.Add(this.TabButton);
            this.tabPanel.Location = new System.Drawing.Point(96, 0);
            this.tabPanel.Margin = new System.Windows.Forms.Padding(0);
            this.tabPanel.Name = "tabPanel";
            this.tabPanel.Size = new System.Drawing.Size(72, 48);
            this.tabPanel.TabIndex = 41;
            // 
            // TabButton
            // 
            this.TabButton.BackgroundImage = global::Wx3270.Properties.Resources.BlankWide48;
            this.TabButton.FlatAppearance.BorderSize = 0;
            this.TabButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TabButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabButton.ForeColor = System.Drawing.Color.DarkGray;
            this.TabButton.Location = new System.Drawing.Point(0, 0);
            this.TabButton.Margin = new System.Windows.Forms.Padding(0);
            this.TabButton.Name = "TabButton";
            this.TabButton.Size = new System.Drawing.Size(72, 48);
            this.TabButton.TabIndex = 8;
            this.TabButton.TabStop = false;
            this.TabButton.Tag = "";
            this.TabButton.Text = "→|";
            this.TabButton.UseVisualStyleBackColor = true;
            this.TabButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.TabButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Controls.Add(this.BlankButton9);
            this.panel10.Location = new System.Drawing.Point(48, 192);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(48, 48);
            this.panel10.TabIndex = 38;
            // 
            // BlankButton9
            // 
            this.BlankButton9.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton9.FlatAppearance.BorderSize = 0;
            this.BlankButton9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton9.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton9.Location = new System.Drawing.Point(0, 0);
            this.BlankButton9.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton9.Name = "BlankButton9";
            this.BlankButton9.Size = new System.Drawing.Size(48, 48);
            this.BlankButton9.TabIndex = 0;
            this.BlankButton9.TabStop = false;
            this.BlankButton9.Tag = "";
            this.BlankButton9.UseVisualStyleBackColor = true;
            this.BlankButton9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton9.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Controls.Add(this.BlankButton7);
            this.panel9.Location = new System.Drawing.Point(48, 144);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(48, 48);
            this.panel9.TabIndex = 38;
            // 
            // BlankButton7
            // 
            this.BlankButton7.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton7.FlatAppearance.BorderSize = 0;
            this.BlankButton7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton7.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton7.Location = new System.Drawing.Point(0, 0);
            this.BlankButton7.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton7.Name = "BlankButton7";
            this.BlankButton7.Size = new System.Drawing.Size(48, 48);
            this.BlankButton7.TabIndex = 0;
            this.BlankButton7.TabStop = false;
            this.BlankButton7.Tag = "";
            this.BlankButton7.UseVisualStyleBackColor = true;
            this.BlankButton7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton7.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Controls.Add(this.BlankButton5);
            this.panel8.Location = new System.Drawing.Point(48, 96);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(48, 48);
            this.panel8.TabIndex = 38;
            // 
            // BlankButton5
            // 
            this.BlankButton5.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton5.FlatAppearance.BorderSize = 0;
            this.BlankButton5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton5.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton5.Location = new System.Drawing.Point(0, 0);
            this.BlankButton5.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton5.Name = "BlankButton5";
            this.BlankButton5.Size = new System.Drawing.Size(48, 48);
            this.BlankButton5.TabIndex = 0;
            this.BlankButton5.TabStop = false;
            this.BlankButton5.Tag = "";
            this.BlankButton5.UseVisualStyleBackColor = true;
            this.BlankButton5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton5.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Controls.Add(this.Blank1Buton);
            this.panel6.Location = new System.Drawing.Point(48, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(48, 48);
            this.panel6.TabIndex = 38;
            // 
            // Blank1Buton
            // 
            this.Blank1Buton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.Blank1Buton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Blank1Buton.FlatAppearance.BorderSize = 0;
            this.Blank1Buton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.Blank1Buton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.Blank1Buton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Blank1Buton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blank1Buton.ForeColor = System.Drawing.Color.DarkGray;
            this.Blank1Buton.Location = new System.Drawing.Point(0, 0);
            this.Blank1Buton.Margin = new System.Windows.Forms.Padding(0);
            this.Blank1Buton.Name = "Blank1Buton";
            this.Blank1Buton.Size = new System.Drawing.Size(48, 48);
            this.Blank1Buton.TabIndex = 0;
            this.Blank1Buton.TabStop = false;
            this.Blank1Buton.Tag = "";
            this.Blank1Buton.UseVisualStyleBackColor = true;
            this.Blank1Buton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.Blank1Buton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Controls.Add(this.BlankButton8);
            this.panel5.Location = new System.Drawing.Point(0, 192);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(48, 48);
            this.panel5.TabIndex = 38;
            // 
            // BlankButton8
            // 
            this.BlankButton8.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton8.FlatAppearance.BorderSize = 0;
            this.BlankButton8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton8.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton8.Location = new System.Drawing.Point(0, 0);
            this.BlankButton8.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton8.Name = "BlankButton8";
            this.BlankButton8.Size = new System.Drawing.Size(48, 48);
            this.BlankButton8.TabIndex = 0;
            this.BlankButton8.TabStop = false;
            this.BlankButton8.Tag = "";
            this.BlankButton8.UseVisualStyleBackColor = true;
            this.BlankButton8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton8.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Controls.Add(this.BlankButton6);
            this.panel4.Location = new System.Drawing.Point(0, 144);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(48, 48);
            this.panel4.TabIndex = 38;
            // 
            // BlankButton6
            // 
            this.BlankButton6.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton6.FlatAppearance.BorderSize = 0;
            this.BlankButton6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton6.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton6.Location = new System.Drawing.Point(0, 0);
            this.BlankButton6.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton6.Name = "BlankButton6";
            this.BlankButton6.Size = new System.Drawing.Size(48, 48);
            this.BlankButton6.TabIndex = 0;
            this.BlankButton6.TabStop = false;
            this.BlankButton6.Tag = "";
            this.BlankButton6.UseVisualStyleBackColor = true;
            this.BlankButton6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton6.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.BlankButton4);
            this.panel3.Location = new System.Drawing.Point(0, 96);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(48, 48);
            this.panel3.TabIndex = 38;
            // 
            // BlankButton4
            // 
            this.BlankButton4.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton4.FlatAppearance.BorderSize = 0;
            this.BlankButton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton4.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton4.Location = new System.Drawing.Point(0, 0);
            this.BlankButton4.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton4.Name = "BlankButton4";
            this.BlankButton4.Size = new System.Drawing.Size(48, 48);
            this.BlankButton4.TabIndex = 0;
            this.BlankButton4.TabStop = false;
            this.BlankButton4.Tag = "";
            this.BlankButton4.UseVisualStyleBackColor = true;
            this.BlankButton4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton4.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.Blank2Button);
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(48, 48);
            this.panel2.TabIndex = 38;
            // 
            // Blank2Button
            // 
            this.Blank2Button.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.Blank2Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Blank2Button.FlatAppearance.BorderSize = 0;
            this.Blank2Button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.Blank2Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.Blank2Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Blank2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blank2Button.ForeColor = System.Drawing.Color.DarkGray;
            this.Blank2Button.Location = new System.Drawing.Point(0, 0);
            this.Blank2Button.Margin = new System.Windows.Forms.Padding(0);
            this.Blank2Button.Name = "Blank2Button";
            this.Blank2Button.Size = new System.Drawing.Size(48, 48);
            this.Blank2Button.TabIndex = 0;
            this.Blank2Button.TabStop = false;
            this.Blank2Button.Tag = "";
            this.Blank2Button.UseVisualStyleBackColor = true;
            this.Blank2Button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.Blank2Button.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.NotButton);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(48, 48);
            this.panel1.TabIndex = 38;
            // 
            // NotButton
            // 
            this.NotButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.NotButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.NotButton.FlatAppearance.BorderSize = 0;
            this.NotButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.NotButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.NotButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NotButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NotButton.ForeColor = System.Drawing.Color.DarkGray;
            this.NotButton.Location = new System.Drawing.Point(0, 0);
            this.NotButton.Margin = new System.Windows.Forms.Padding(0);
            this.NotButton.Name = "NotButton";
            this.NotButton.Size = new System.Drawing.Size(48, 48);
            this.NotButton.TabIndex = 0;
            this.NotButton.TabStop = false;
            this.NotButton.Tag = "";
            this.NotButton.Text = "¬";
            this.NotButton.UseVisualStyleBackColor = true;
            this.NotButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.NotButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // enterPanel
            // 
            this.enterPanel.BackColor = System.Drawing.Color.Black;
            this.enterPanel.Controls.Add(this.EnterButton);
            this.enterPanel.Location = new System.Drawing.Point(96, 192);
            this.enterPanel.Margin = new System.Windows.Forms.Padding(0);
            this.enterPanel.Name = "enterPanel";
            this.enterPanel.Size = new System.Drawing.Size(72, 48);
            this.enterPanel.TabIndex = 39;
            // 
            // EnterButton
            // 
            this.EnterButton.BackgroundImage = global::Wx3270.Properties.Resources.BlankWide48;
            this.EnterButton.FlatAppearance.BorderSize = 0;
            this.EnterButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnterButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterButton.ForeColor = System.Drawing.Color.DarkGray;
            this.EnterButton.Location = new System.Drawing.Point(0, 0);
            this.EnterButton.Margin = new System.Windows.Forms.Padding(0);
            this.EnterButton.Name = "EnterButton";
            this.EnterButton.Size = new System.Drawing.Size(72, 48);
            this.EnterButton.TabIndex = 10;
            this.EnterButton.TabStop = false;
            this.EnterButton.Tag = "";
            this.EnterButton.Text = "ENTER";
            this.EnterButton.UseVisualStyleBackColor = true;
            this.EnterButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.EnterButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // newlinePanel
            // 
            this.newlinePanel.BackColor = System.Drawing.Color.Black;
            this.newlinePanel.Controls.Add(this.NewlineButton);
            this.newlinePanel.Location = new System.Drawing.Point(96, 96);
            this.newlinePanel.Margin = new System.Windows.Forms.Padding(0);
            this.newlinePanel.Name = "newlinePanel";
            this.newMiddlePanel.SetRowSpan(this.newlinePanel, 2);
            this.newlinePanel.Size = new System.Drawing.Size(72, 96);
            this.newlinePanel.TabIndex = 39;
            // 
            // NewlineButton
            // 
            this.NewlineButton.BackgroundImage = global::Wx3270.Properties.Resources.BlankVert;
            this.NewlineButton.FlatAppearance.BorderSize = 0;
            this.NewlineButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewlineButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewlineButton.ForeColor = System.Drawing.Color.DarkGray;
            this.NewlineButton.Location = new System.Drawing.Point(0, 0);
            this.NewlineButton.Margin = new System.Windows.Forms.Padding(0);
            this.NewlineButton.Name = "NewlineButton";
            this.NewlineButton.Size = new System.Drawing.Size(72, 96);
            this.NewlineButton.TabIndex = 11;
            this.NewlineButton.TabStop = false;
            this.NewlineButton.Tag = "";
            this.NewlineButton.Text = "⤶";
            this.NewlineButton.UseVisualStyleBackColor = true;
            this.NewlineButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.NewlineButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Controls.Add(this.BlankButton3);
            this.panel7.Location = new System.Drawing.Point(48, 48);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(48, 48);
            this.panel7.TabIndex = 38;
            // 
            // BlankButton3
            // 
            this.BlankButton3.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.BlankButton3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BlankButton3.FlatAppearance.BorderSize = 0;
            this.BlankButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.BlankButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.BlankButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BlankButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlankButton3.ForeColor = System.Drawing.Color.DarkGray;
            this.BlankButton3.Location = new System.Drawing.Point(0, 0);
            this.BlankButton3.Margin = new System.Windows.Forms.Padding(0);
            this.BlankButton3.Name = "BlankButton3";
            this.BlankButton3.Size = new System.Drawing.Size(48, 48);
            this.BlankButton3.TabIndex = 0;
            this.BlankButton3.TabStop = false;
            this.BlankButton3.Tag = "";
            this.BlankButton3.UseVisualStyleBackColor = true;
            this.BlankButton3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.BlankButton3.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // newRightPanel
            // 
            this.newRightPanel.AutoSize = true;
            this.newRightPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.newRightPanel.BackColor = System.Drawing.Color.Black;
            this.newRightPanel.ColumnCount = 3;
            this.newRightPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newRightPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newRightPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.newRightPanel.Controls.Add(this.rightPanel, 2, 4);
            this.newRightPanel.Controls.Add(this.downPanel, 1, 4);
            this.newRightPanel.Controls.Add(this.leftPanel, 0, 4);
            this.newRightPanel.Controls.Add(this.deletePanel, 2, 3);
            this.newRightPanel.Controls.Add(this.upPanel, 1, 3);
            this.newRightPanel.Controls.Add(this.insertPanel, 0, 3);
            this.newRightPanel.Controls.Add(this.sysReqPanel, 2, 2);
            this.newRightPanel.Controls.Add(this.cursorBlinkPanel, 1, 2);
            this.newRightPanel.Controls.Add(this.attnPanel, 0, 2);
            this.newRightPanel.Controls.Add(this.fieldMarkPanel, 2, 1);
            this.newRightPanel.Controls.Add(this.dupPanel, 1, 1);
            this.newRightPanel.Controls.Add(this.eraseEofPanel, 0, 1);
            this.newRightPanel.Controls.Add(this.clearPanel, 2, 0);
            this.newRightPanel.Controls.Add(this.cursorSelectPanel, 1, 0);
            this.newRightPanel.Controls.Add(this.eraseInputPanel, 0, 0);
            this.newRightPanel.Location = new System.Drawing.Point(332, 0);
            this.newRightPanel.Margin = new System.Windows.Forms.Padding(0);
            this.newRightPanel.Name = "newRightPanel";
            this.newRightPanel.RowCount = 5;
            this.newRightPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newRightPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newRightPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newRightPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newRightPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.newRightPanel.Size = new System.Drawing.Size(144, 240);
            this.newRightPanel.TabIndex = 2;
            // 
            // rightPanel
            // 
            this.rightPanel.BackColor = System.Drawing.Color.Black;
            this.rightPanel.Controls.Add(this.RightButton);
            this.rightPanel.Location = new System.Drawing.Point(96, 192);
            this.rightPanel.Margin = new System.Windows.Forms.Padding(0);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(48, 48);
            this.rightPanel.TabIndex = 38;
            // 
            // RightButton
            // 
            this.RightButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.RightButton.FlatAppearance.BorderSize = 0;
            this.RightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RightButton.ForeColor = System.Drawing.Color.DarkGray;
            this.RightButton.Location = new System.Drawing.Point(0, 0);
            this.RightButton.Margin = new System.Windows.Forms.Padding(0);
            this.RightButton.Name = "RightButton";
            this.RightButton.Size = new System.Drawing.Size(48, 48);
            this.RightButton.TabIndex = 23;
            this.RightButton.TabStop = false;
            this.RightButton.Tag = "";
            this.RightButton.Text = "→";
            this.RightButton.UseVisualStyleBackColor = true;
            this.RightButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.RightButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // downPanel
            // 
            this.downPanel.BackColor = System.Drawing.Color.Black;
            this.downPanel.Controls.Add(this.DownButton);
            this.downPanel.Location = new System.Drawing.Point(48, 192);
            this.downPanel.Margin = new System.Windows.Forms.Padding(0);
            this.downPanel.Name = "downPanel";
            this.downPanel.Size = new System.Drawing.Size(48, 48);
            this.downPanel.TabIndex = 39;
            // 
            // DownButton
            // 
            this.DownButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.DownButton.FlatAppearance.BorderSize = 0;
            this.DownButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DownButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DownButton.ForeColor = System.Drawing.Color.DarkGray;
            this.DownButton.Location = new System.Drawing.Point(0, 0);
            this.DownButton.Margin = new System.Windows.Forms.Padding(0);
            this.DownButton.Name = "DownButton";
            this.DownButton.Size = new System.Drawing.Size(48, 48);
            this.DownButton.TabIndex = 24;
            this.DownButton.TabStop = false;
            this.DownButton.Tag = "";
            this.DownButton.Text = "↓";
            this.DownButton.UseVisualStyleBackColor = true;
            this.DownButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.DownButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // leftPanel
            // 
            this.leftPanel.BackColor = System.Drawing.Color.Black;
            this.leftPanel.Controls.Add(this.LeftButton);
            this.leftPanel.Location = new System.Drawing.Point(0, 192);
            this.leftPanel.Margin = new System.Windows.Forms.Padding(0);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(48, 48);
            this.leftPanel.TabIndex = 39;
            // 
            // LeftButton
            // 
            this.LeftButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.LeftButton.FlatAppearance.BorderSize = 0;
            this.LeftButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LeftButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftButton.ForeColor = System.Drawing.Color.DarkGray;
            this.LeftButton.Location = new System.Drawing.Point(0, 0);
            this.LeftButton.Margin = new System.Windows.Forms.Padding(0);
            this.LeftButton.Name = "LeftButton";
            this.LeftButton.Size = new System.Drawing.Size(48, 48);
            this.LeftButton.TabIndex = 6;
            this.LeftButton.TabStop = false;
            this.LeftButton.Tag = "";
            this.LeftButton.Text = "←";
            this.LeftButton.UseVisualStyleBackColor = true;
            this.LeftButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.LeftButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // deletePanel
            // 
            this.deletePanel.BackColor = System.Drawing.Color.Black;
            this.deletePanel.Controls.Add(this.DeleteButton);
            this.deletePanel.Location = new System.Drawing.Point(96, 144);
            this.deletePanel.Margin = new System.Windows.Forms.Padding(0);
            this.deletePanel.Name = "deletePanel";
            this.deletePanel.Size = new System.Drawing.Size(48, 48);
            this.deletePanel.TabIndex = 39;
            // 
            // DeleteButton
            // 
            this.DeleteButton.BackgroundImage = global::Wx3270.Properties.Resources.Delete48;
            this.DeleteButton.FlatAppearance.BorderSize = 0;
            this.DeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.ForeColor = System.Drawing.Color.DarkGray;
            this.DeleteButton.Location = new System.Drawing.Point(0, 0);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(0);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(48, 48);
            this.DeleteButton.TabIndex = 26;
            this.DeleteButton.TabStop = false;
            this.DeleteButton.Tag = "";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.DeleteButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // upPanel
            // 
            this.upPanel.BackColor = System.Drawing.Color.Black;
            this.upPanel.Controls.Add(this.UpButton);
            this.upPanel.Location = new System.Drawing.Point(48, 144);
            this.upPanel.Margin = new System.Windows.Forms.Padding(0);
            this.upPanel.Name = "upPanel";
            this.upPanel.Size = new System.Drawing.Size(48, 48);
            this.upPanel.TabIndex = 39;
            // 
            // UpButton
            // 
            this.UpButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.UpButton.FlatAppearance.BorderSize = 0;
            this.UpButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpButton.ForeColor = System.Drawing.Color.DarkGray;
            this.UpButton.Location = new System.Drawing.Point(0, 0);
            this.UpButton.Margin = new System.Windows.Forms.Padding(0);
            this.UpButton.Name = "UpButton";
            this.UpButton.Size = new System.Drawing.Size(48, 48);
            this.UpButton.TabIndex = 5;
            this.UpButton.TabStop = false;
            this.UpButton.Tag = "";
            this.UpButton.Text = "↑";
            this.UpButton.UseVisualStyleBackColor = true;
            this.UpButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.UpButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // insertPanel
            // 
            this.insertPanel.BackColor = System.Drawing.Color.Black;
            this.insertPanel.Controls.Add(this.InsertButton);
            this.insertPanel.Location = new System.Drawing.Point(0, 144);
            this.insertPanel.Margin = new System.Windows.Forms.Padding(0);
            this.insertPanel.Name = "insertPanel";
            this.insertPanel.Size = new System.Drawing.Size(48, 48);
            this.insertPanel.TabIndex = 39;
            // 
            // InsertButton
            // 
            this.InsertButton.BackgroundImage = global::Wx3270.Properties.Resources.Insert48_2;
            this.InsertButton.FlatAppearance.BorderSize = 0;
            this.InsertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InsertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertButton.ForeColor = System.Drawing.Color.DarkGray;
            this.InsertButton.Location = new System.Drawing.Point(0, 0);
            this.InsertButton.Margin = new System.Windows.Forms.Padding(0);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(48, 48);
            this.InsertButton.TabIndex = 25;
            this.InsertButton.TabStop = false;
            this.InsertButton.Tag = "";
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.InsertButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // sysReqPanel
            // 
            this.sysReqPanel.BackColor = System.Drawing.Color.Black;
            this.sysReqPanel.Controls.Add(this.SysReqButton);
            this.sysReqPanel.Location = new System.Drawing.Point(96, 96);
            this.sysReqPanel.Margin = new System.Windows.Forms.Padding(0);
            this.sysReqPanel.Name = "sysReqPanel";
            this.sysReqPanel.Size = new System.Drawing.Size(48, 48);
            this.sysReqPanel.TabIndex = 39;
            // 
            // SysReqButton
            // 
            this.SysReqButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.SysReqButton.FlatAppearance.BorderSize = 0;
            this.SysReqButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SysReqButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SysReqButton.ForeColor = System.Drawing.Color.DarkGray;
            this.SysReqButton.Location = new System.Drawing.Point(0, 0);
            this.SysReqButton.Margin = new System.Windows.Forms.Padding(0);
            this.SysReqButton.Name = "SysReqButton";
            this.SysReqButton.Size = new System.Drawing.Size(48, 48);
            this.SysReqButton.TabIndex = 33;
            this.SysReqButton.TabStop = false;
            this.SysReqButton.Tag = "";
            this.SysReqButton.Text = "SYS\r\nREQ";
            this.SysReqButton.UseVisualStyleBackColor = true;
            this.SysReqButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.SysReqButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // cursorBlinkPanel
            // 
            this.cursorBlinkPanel.BackColor = System.Drawing.Color.Black;
            this.cursorBlinkPanel.Controls.Add(this.CursorBlinkButton);
            this.cursorBlinkPanel.Location = new System.Drawing.Point(48, 96);
            this.cursorBlinkPanel.Margin = new System.Windows.Forms.Padding(0);
            this.cursorBlinkPanel.Name = "cursorBlinkPanel";
            this.cursorBlinkPanel.Size = new System.Drawing.Size(48, 48);
            this.cursorBlinkPanel.TabIndex = 39;
            // 
            // CursorBlinkButton
            // 
            this.CursorBlinkButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.CursorBlinkButton.FlatAppearance.BorderSize = 0;
            this.CursorBlinkButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CursorBlinkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CursorBlinkButton.ForeColor = System.Drawing.Color.DarkGray;
            this.CursorBlinkButton.Location = new System.Drawing.Point(0, 0);
            this.CursorBlinkButton.Margin = new System.Windows.Forms.Padding(0);
            this.CursorBlinkButton.Name = "CursorBlinkButton";
            this.CursorBlinkButton.Size = new System.Drawing.Size(48, 48);
            this.CursorBlinkButton.TabIndex = 32;
            this.CursorBlinkButton.TabStop = false;
            this.CursorBlinkButton.Tag = "";
            this.CursorBlinkButton.Text = "CURSR\r\nBLINK";
            this.CursorBlinkButton.UseVisualStyleBackColor = true;
            this.CursorBlinkButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.CursorBlinkButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // attnPanel
            // 
            this.attnPanel.BackColor = System.Drawing.Color.Black;
            this.attnPanel.Controls.Add(this.AttnButton);
            this.attnPanel.Location = new System.Drawing.Point(0, 96);
            this.attnPanel.Margin = new System.Windows.Forms.Padding(0);
            this.attnPanel.Name = "attnPanel";
            this.attnPanel.Size = new System.Drawing.Size(48, 48);
            this.attnPanel.TabIndex = 39;
            // 
            // AttnButton
            // 
            this.AttnButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.AttnButton.FlatAppearance.BorderSize = 0;
            this.AttnButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AttnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttnButton.ForeColor = System.Drawing.Color.DarkGray;
            this.AttnButton.Location = new System.Drawing.Point(0, 0);
            this.AttnButton.Margin = new System.Windows.Forms.Padding(0);
            this.AttnButton.Name = "AttnButton";
            this.AttnButton.Size = new System.Drawing.Size(48, 48);
            this.AttnButton.TabIndex = 31;
            this.AttnButton.TabStop = false;
            this.AttnButton.Tag = "";
            this.AttnButton.Text = "ATTN";
            this.AttnButton.UseVisualStyleBackColor = true;
            this.AttnButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.AttnButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // fieldMarkPanel
            // 
            this.fieldMarkPanel.BackColor = System.Drawing.Color.Black;
            this.fieldMarkPanel.Controls.Add(this.FieldMarkButton);
            this.fieldMarkPanel.Location = new System.Drawing.Point(96, 48);
            this.fieldMarkPanel.Margin = new System.Windows.Forms.Padding(0);
            this.fieldMarkPanel.Name = "fieldMarkPanel";
            this.fieldMarkPanel.Size = new System.Drawing.Size(48, 48);
            this.fieldMarkPanel.TabIndex = 39;
            // 
            // FieldMarkButton
            // 
            this.FieldMarkButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.FieldMarkButton.FlatAppearance.BorderSize = 0;
            this.FieldMarkButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FieldMarkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FieldMarkButton.ForeColor = System.Drawing.Color.DarkGray;
            this.FieldMarkButton.Location = new System.Drawing.Point(0, 0);
            this.FieldMarkButton.Margin = new System.Windows.Forms.Padding(0);
            this.FieldMarkButton.Name = "FieldMarkButton";
            this.FieldMarkButton.Size = new System.Drawing.Size(48, 48);
            this.FieldMarkButton.TabIndex = 28;
            this.FieldMarkButton.TabStop = false;
            this.FieldMarkButton.Tag = "";
            this.FieldMarkButton.Text = "FIELD\r\nMARK";
            this.FieldMarkButton.UseVisualStyleBackColor = true;
            this.FieldMarkButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.FieldMarkButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // dupPanel
            // 
            this.dupPanel.BackColor = System.Drawing.Color.Black;
            this.dupPanel.Controls.Add(this.DupButton);
            this.dupPanel.Location = new System.Drawing.Point(48, 48);
            this.dupPanel.Margin = new System.Windows.Forms.Padding(0);
            this.dupPanel.Name = "dupPanel";
            this.dupPanel.Size = new System.Drawing.Size(48, 48);
            this.dupPanel.TabIndex = 39;
            // 
            // DupButton
            // 
            this.DupButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.DupButton.FlatAppearance.BorderSize = 0;
            this.DupButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DupButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DupButton.ForeColor = System.Drawing.Color.DarkGray;
            this.DupButton.Location = new System.Drawing.Point(0, 0);
            this.DupButton.Margin = new System.Windows.Forms.Padding(0);
            this.DupButton.Name = "DupButton";
            this.DupButton.Size = new System.Drawing.Size(48, 48);
            this.DupButton.TabIndex = 27;
            this.DupButton.TabStop = false;
            this.DupButton.Tag = "";
            this.DupButton.Text = "DUP";
            this.DupButton.UseVisualStyleBackColor = true;
            this.DupButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.DupButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // eraseEofPanel
            // 
            this.eraseEofPanel.BackColor = System.Drawing.Color.Black;
            this.eraseEofPanel.Controls.Add(this.EraseEOFbutton);
            this.eraseEofPanel.Location = new System.Drawing.Point(0, 48);
            this.eraseEofPanel.Margin = new System.Windows.Forms.Padding(0);
            this.eraseEofPanel.Name = "eraseEofPanel";
            this.eraseEofPanel.Size = new System.Drawing.Size(48, 48);
            this.eraseEofPanel.TabIndex = 39;
            // 
            // EraseEOFbutton
            // 
            this.EraseEOFbutton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.EraseEOFbutton.FlatAppearance.BorderSize = 0;
            this.EraseEOFbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EraseEOFbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EraseEOFbutton.ForeColor = System.Drawing.Color.DarkGray;
            this.EraseEOFbutton.Location = new System.Drawing.Point(0, 0);
            this.EraseEOFbutton.Margin = new System.Windows.Forms.Padding(0);
            this.EraseEOFbutton.Name = "EraseEOFbutton";
            this.EraseEOFbutton.Size = new System.Drawing.Size(48, 48);
            this.EraseEOFbutton.TabIndex = 1;
            this.EraseEOFbutton.TabStop = false;
            this.EraseEOFbutton.Tag = "";
            this.EraseEOFbutton.Text = "ERASE\r\nEOF";
            this.EraseEOFbutton.UseVisualStyleBackColor = true;
            this.EraseEOFbutton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.EraseEOFbutton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // clearPanel
            // 
            this.clearPanel.BackColor = System.Drawing.Color.Black;
            this.clearPanel.Controls.Add(this.ClearButton);
            this.clearPanel.Location = new System.Drawing.Point(96, 0);
            this.clearPanel.Margin = new System.Windows.Forms.Padding(0);
            this.clearPanel.Name = "clearPanel";
            this.clearPanel.Size = new System.Drawing.Size(48, 48);
            this.clearPanel.TabIndex = 39;
            // 
            // ClearButton
            // 
            this.ClearButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.ClearButton.FlatAppearance.BorderSize = 0;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.ForeColor = System.Drawing.Color.DarkGray;
            this.ClearButton.Location = new System.Drawing.Point(0, 0);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(0);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(48, 48);
            this.ClearButton.TabIndex = 2;
            this.ClearButton.TabStop = false;
            this.ClearButton.Tag = "";
            this.ClearButton.Text = "CLEAR";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.ClearButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // cursorSelectPanel
            // 
            this.cursorSelectPanel.BackColor = System.Drawing.Color.Black;
            this.cursorSelectPanel.Controls.Add(this.CursorSelectButton);
            this.cursorSelectPanel.Location = new System.Drawing.Point(48, 0);
            this.cursorSelectPanel.Margin = new System.Windows.Forms.Padding(0);
            this.cursorSelectPanel.Name = "cursorSelectPanel";
            this.cursorSelectPanel.Size = new System.Drawing.Size(48, 48);
            this.cursorSelectPanel.TabIndex = 39;
            // 
            // CursorSelectButton
            // 
            this.CursorSelectButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.CursorSelectButton.FlatAppearance.BorderSize = 0;
            this.CursorSelectButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CursorSelectButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CursorSelectButton.ForeColor = System.Drawing.Color.DarkGray;
            this.CursorSelectButton.Location = new System.Drawing.Point(0, 0);
            this.CursorSelectButton.Margin = new System.Windows.Forms.Padding(0);
            this.CursorSelectButton.Name = "CursorSelectButton";
            this.CursorSelectButton.Size = new System.Drawing.Size(48, 48);
            this.CursorSelectButton.TabIndex = 4;
            this.CursorSelectButton.TabStop = false;
            this.CursorSelectButton.Tag = "";
            this.CursorSelectButton.Text = "CURSR\r\nSEL";
            this.CursorSelectButton.UseVisualStyleBackColor = true;
            this.CursorSelectButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.CursorSelectButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // eraseInputPanel
            // 
            this.eraseInputPanel.BackColor = System.Drawing.Color.Black;
            this.eraseInputPanel.Controls.Add(this.EraseInputButton);
            this.eraseInputPanel.Location = new System.Drawing.Point(0, 0);
            this.eraseInputPanel.Margin = new System.Windows.Forms.Padding(0);
            this.eraseInputPanel.Name = "eraseInputPanel";
            this.eraseInputPanel.Size = new System.Drawing.Size(48, 48);
            this.eraseInputPanel.TabIndex = 39;
            // 
            // EraseInputButton
            // 
            this.EraseInputButton.BackgroundImage = global::Wx3270.Properties.Resources.Blank48;
            this.EraseInputButton.FlatAppearance.BorderSize = 0;
            this.EraseInputButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EraseInputButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EraseInputButton.ForeColor = System.Drawing.Color.DarkGray;
            this.EraseInputButton.Location = new System.Drawing.Point(0, 0);
            this.EraseInputButton.Margin = new System.Windows.Forms.Padding(0);
            this.EraseInputButton.Name = "EraseInputButton";
            this.EraseInputButton.Size = new System.Drawing.Size(48, 48);
            this.EraseInputButton.TabIndex = 3;
            this.EraseInputButton.TabStop = false;
            this.EraseInputButton.Tag = "";
            this.EraseInputButton.Text = "ERASE\r\nINPUT";
            this.EraseInputButton.UseVisualStyleBackColor = true;
            this.EraseInputButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.KeypadMouseDown);
            this.EraseInputButton.MouseEnter += new System.EventHandler(this.Keypad_Enter);
            // 
            // keypadOuterPanel
            // 
            this.keypadOuterPanel.AutoSize = true;
            this.keypadOuterPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.keypadOuterPanel.Controls.Add(this.KeypadPanel);
            this.keypadOuterPanel.Location = new System.Drawing.Point(0, 0);
            this.keypadOuterPanel.Margin = new System.Windows.Forms.Padding(0);
            this.keypadOuterPanel.Name = "keypadOuterPanel";
            this.keypadOuterPanel.Size = new System.Drawing.Size(476, 240);
            this.keypadOuterPanel.TabIndex = 37;
            // 
            // Keypad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(625, 397);
            this.Controls.Add(this.keypadOuterPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Keypad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "wx3270 Keypad";
            this.Activated += new System.EventHandler(this.Keypad_Activated);
            this.Deactivate += new System.EventHandler(this.Keypad_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Keypad_FormClosing);
            this.Enter += new System.EventHandler(this.Keypad_Enter);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Keypad_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Keypad_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Keypad_KeyUp);
            this.MouseCaptureChanged += new System.EventHandler(this.Keypad_Enter);
            this.KeypadPanel.ResumeLayout(false);
            this.KeypadPanel.PerformLayout();
            this.newLeftPanel.ResumeLayout(false);
            this.ResetPanel.ResumeLayout(false);
            this.pa2Panel.ResumeLayout(false);
            this.pa1Panel.ResumeLayout(false);
            this.pf12Panel.ResumeLayout(false);
            this.pf11Panel.ResumeLayout(false);
            this.pa10Panel.ResumeLayout(false);
            this.pf9Panel.ResumeLayout(false);
            this.pf8Panel.ResumeLayout(false);
            this.pf7Panel.ResumeLayout(false);
            this.pf6Panel.ResumeLayout(false);
            this.pf5Panel.ResumeLayout(false);
            this.pf4Panel.ResumeLayout(false);
            this.pf3Panel.ResumeLayout(false);
            this.pf1Panel.ResumeLayout(false);
            this.pf2Panel.ResumeLayout(false);
            this.newMiddlePanel.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.tabPanel.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.enterPanel.ResumeLayout(false);
            this.newlinePanel.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.newRightPanel.ResumeLayout(false);
            this.rightPanel.ResumeLayout(false);
            this.downPanel.ResumeLayout(false);
            this.leftPanel.ResumeLayout(false);
            this.deletePanel.ResumeLayout(false);
            this.upPanel.ResumeLayout(false);
            this.insertPanel.ResumeLayout(false);
            this.sysReqPanel.ResumeLayout(false);
            this.cursorBlinkPanel.ResumeLayout(false);
            this.attnPanel.ResumeLayout(false);
            this.fieldMarkPanel.ResumeLayout(false);
            this.dupPanel.ResumeLayout(false);
            this.eraseEofPanel.ResumeLayout(false);
            this.clearPanel.ResumeLayout(false);
            this.cursorSelectPanel.ResumeLayout(false);
            this.eraseInputPanel.ResumeLayout(false);
            this.keypadOuterPanel.ResumeLayout(false);
            this.keypadOuterPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel KeypadPanel;
        private Wx3270.NoSelectButton ClearButton;
        private Wx3270.NoSelectButton RightButton;
        private Wx3270.NoSelectButton SysReqButton;
        private Wx3270.NoSelectButton DownButton;
        private Wx3270.NoSelectButton CursorBlinkButton;
        private Wx3270.NoSelectButton InsertButton;
        private Wx3270.NoSelectButton EraseInputButton;
        private Wx3270.NoSelectButton LeftButton;
        private Wx3270.NoSelectButton AttnButton;
        private Wx3270.NoSelectButton DeleteButton;
        private Wx3270.NoSelectButton EraseEOFbutton;
        private Wx3270.NoSelectButton UpButton;
        private Wx3270.NoSelectButton DupButton;
        private Wx3270.NoSelectButton FieldMarkButton;
        private Wx3270.NoSelectButton CursorSelectButton;
        private Wx3270.NoSelectButton NewlineButton;
        private Wx3270.NoSelectButton EnterButton;
        private Wx3270.NoSelectButton PF1button;
        private Wx3270.NoSelectButton ResetButton;
        private Wx3270.NoSelectButton PF11button;
        private Wx3270.NoSelectButton PF10button;
        private Wx3270.NoSelectButton PF12button;
        private Wx3270.NoSelectButton PF4button;
        private Wx3270.NoSelectButton PF5button;
        private Wx3270.NoSelectButton PF3button;
        private Wx3270.NoSelectButton PF6button;
        private Wx3270.NoSelectButton PA2button;
        private Wx3270.NoSelectButton PF2button;
        private Wx3270.NoSelectButton PF7button;
        private Wx3270.NoSelectButton PA1button;
        private Wx3270.NoSelectButton PF8button;
        private Wx3270.NoSelectButton PF9button;
        public System.Windows.Forms.TableLayoutPanel newLeftPanel;
        public System.Windows.Forms.TableLayoutPanel newMiddlePanel;
        public System.Windows.Forms.TableLayoutPanel newRightPanel;
        private System.Windows.Forms.Panel pf1Panel;
        private System.Windows.Forms.Panel pf3Panel;
        private System.Windows.Forms.Panel pf2Panel;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Panel ResetPanel;
        private System.Windows.Forms.Panel pa2Panel;
        private System.Windows.Forms.Panel pa1Panel;
        private System.Windows.Forms.Panel pf12Panel;
        private System.Windows.Forms.Panel pf11Panel;
        private System.Windows.Forms.Panel pa10Panel;
        private System.Windows.Forms.Panel pf9Panel;
        private System.Windows.Forms.Panel pf8Panel;
        private System.Windows.Forms.Panel pf7Panel;
        private System.Windows.Forms.Panel pf6Panel;
        private System.Windows.Forms.Panel pf5Panel;
        private System.Windows.Forms.Panel pf4Panel;
        private System.Windows.Forms.Panel enterPanel;
        private System.Windows.Forms.Panel newlinePanel;
        private System.Windows.Forms.Panel downPanel;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.Panel deletePanel;
        private System.Windows.Forms.Panel upPanel;
        private System.Windows.Forms.Panel insertPanel;
        private System.Windows.Forms.Panel sysReqPanel;
        private System.Windows.Forms.Panel cursorBlinkPanel;
        private System.Windows.Forms.Panel attnPanel;
        private System.Windows.Forms.Panel fieldMarkPanel;
        private System.Windows.Forms.Panel dupPanel;
        private System.Windows.Forms.Panel eraseEofPanel;
        private System.Windows.Forms.Panel clearPanel;
        private System.Windows.Forms.Panel cursorSelectPanel;
        private System.Windows.Forms.Panel eraseInputPanel;
        private System.Windows.Forms.Panel keypadOuterPanel;
        private System.Windows.Forms.Panel panel10;
        private NoSelectButton BlankButton9;
        private System.Windows.Forms.Panel panel9;
        private NoSelectButton BlankButton7;
        private System.Windows.Forms.Panel panel8;
        private NoSelectButton BlankButton5;
        private System.Windows.Forms.Panel panel6;
        private NoSelectButton Blank1Buton;
        private System.Windows.Forms.Panel panel5;
        private NoSelectButton BlankButton8;
        private System.Windows.Forms.Panel panel4;
        private NoSelectButton BlankButton6;
        private System.Windows.Forms.Panel panel3;
        private NoSelectButton BlankButton4;
        private System.Windows.Forms.Panel panel2;
        private NoSelectButton Blank2Button;
        private System.Windows.Forms.Panel panel1;
        private NoSelectButton NotButton;
        private System.Windows.Forms.Panel panel7;
        private NoSelectButton BlankButton3;
        private NoSelectButton BackTabButton;
        private System.Windows.Forms.Panel tabPanel;
        private NoSelectButton TabButton;
        private System.Windows.Forms.Panel panel17;
    }
}